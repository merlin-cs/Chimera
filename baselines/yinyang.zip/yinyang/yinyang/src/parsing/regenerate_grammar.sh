#! /bin/sh
java -jar antlr-4.9.2-complete.jar -Dlanguage=Python3 SMTLIBv2.g4
