Installation
==============

To install a stable version of yinyang use:

```
pip3 install yinyang
```

The following commands clone yinyang and install the antlr4 python runtime.

.. code-block:: bash

    $ git clone https://github.com/testsmt/yinyang.git
    $ pip3 install antlr4-python3-runtime==4.9.2
